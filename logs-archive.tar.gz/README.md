# Logging System

This directory contains log files for the backtesting dashboard. Each widget and API has its own dedicated log file for better debugging and monitoring.

## Log Files

- `portfolio.log` - Portfolio widget and API logs
- `profit_loss.log` - Profit/Loss widget and API logs
- `robinhood.log` - Robinhood integration logs
- `orders.log` - Orders widget and API logs
- `dividends.log` - Dividends widget and API logs
- `server.log` - Main server logs

## Features

### Widget-Specific Logging
Each widget has its own logger that writes to a dedicated file:
```python
from utils.logger import get_widget_logger

logger = get_widget_logger('portfolio')
logger.debug("Debug message")
logger.info("Info message")
logger.warning("Warning message")
logger.error("Error message")
```

### API-Specific Logging
APIs can also have their own loggers:
```python
from utils.logger import get_api_logger

logger = get_api_logger('polygon')
logger.info("API call to Polygon")
```

### Log Management
- **Automatic cleanup**: Log files older than 7 days are automatically cleaned up
- **Size monitoring**: Large log files (>1MB) are flagged in the UI
- **Log viewer**: Built-in web interface to view and manage logs

## API Endpoints

- `GET /logs` - List all log files with metadata
- `GET /logs/{log_name}?lines=100` - Get log content (last N lines)
- `POST /logs/cleanup?days_to_keep=7` - Clean up old log files

## Log Levels

- **DEBUG**: Detailed debugging information
- **INFO**: General information about program execution
- **WARNING**: Warning messages for potentially problematic situations
- **ERROR**: Error messages for serious problems

## Benefits

1. **Reduced server noise**: Widget logs are separated from server logs
2. **Better debugging**: Each component has its own log file
3. **Performance monitoring**: Track API calls and response times
4. **Error tracking**: Isolate issues to specific widgets
5. **Development workflow**: Easy to test and debug individual components

## Usage Examples

### In Widget Code
```python
from utils.logger import get_widget_logger

logger = get_widget_logger('portfolio')

def fetch_portfolio_data():
    logger.info("Starting portfolio data fetch")
    try:
        # ... fetch data ...
        logger.debug(f"Fetched {len(data)} positions")
        return data
    except Exception as e:
        logger.error(f"Failed to fetch portfolio data: {e}")
        raise
```

### In API Code
```python
from utils.logger import get_api_logger

logger = get_api_logger('polygon')

def make_api_call():
    logger.info("Making API call to Polygon")
    try:
        response = requests.get(url)
        logger.debug(f"API response status: {response.status_code}")
        return response.json()
    except Exception as e:
        logger.error(f"API call failed: {e}")
        raise
```

## Log Viewer Widget

The dashboard includes a built-in log viewer widget that allows you to:
- View all log files and their sizes
- Read log content with syntax highlighting
- Clean up old log files
- Monitor log file growth

Access it through the dashboard interface to monitor your system's logging activity. 